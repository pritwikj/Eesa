// module.exports = {
//   reactStrictMode: true,
// }
module.exports = {
  images: {
    loader: 'akamai',
    path: "/eesaweb"
  },
  basePath: '/eesaweb',
}